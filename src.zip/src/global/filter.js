const Filter = function () {}

Filter.install = function (Vue, options) {

}

export default Filter
