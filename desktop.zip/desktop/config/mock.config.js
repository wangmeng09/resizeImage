module.exports = {
	prcessInputAPI: function(url,param){

		console.log(param['loginName'])
		// 这里可以根据输入的数据来处理逻辑
		return url
	}
}
