<template>
  <div>
    <s3-header :company="basic.companyName" :logo="basic.logo" ></s3-header>
    <s3-nav :nav="nav"></s3-nav>
    <!-- <s3-breadcrumb :list="breadcrumb"></s3-breadcrumb> -->
    <el-main class="">
      <router-view ></router-view>
    </el-main>
    <s3-footer :company="basic.companyName" :logo="basic.logo" class="footer"></s3-footer>
  </div>
</template>

<script>

import s3Nav from '@/components/s3-nav'
import s3Header from '@/components/s3-header'
import s3Footer from '@/components/s3-footer'
import s3Breadcrumb from '@/components/s3-breadcrumb'

export default {
  data () {
    return {
      basic: config.basic,
      nav:[],
      breadcrumb: []
    }
  },
  computed:{
    currentRole () {
      return this.$store.state.currentRole
    },
    appid () {
      return this.$store.state.appid
    }
  },
  created(){
    s3.ajax('/user/roleFunction',{},this.appid)
      .then(res =>{
        this.nav = res.menuList
    })
  },
  methods: {},
  watch:{
    currentRole (){
      s3.ajax('/user/roleFunction',{},this.appid)
      .then(res =>{
        this.nav = res.menuList;
        this.$router.push('/')
      })
      .catch(error => {
        this.$alert('获取导航出错!','出错了')
      })
    },
    nav () {
      s3.ajax('/config/leftNav',{},this.appid)
      .then(res => {
      })
      .catch(error => {
        this.$alert('获取导航出错!','出错了')
      })
    }
  },
  components:{
    s3Nav,
    s3Header,
    s3Footer,
    s3Breadcrumb
  }
}
</script>

<style>
  .el-carousel{width:100%;height:300px;}
  .el-carousel__item h3 {
    font-size: 14px;
    opacity: 0.75;
    line-height: 150px;
    margin: 0;
  }
  .el-carousel__item:nth-child(2n) {
     background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n+1) {
     background-color: #d3dce6;
  }
</style>
