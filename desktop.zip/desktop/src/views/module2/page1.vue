<template>
	<div class="main">
		<s3-search></s3-search>
		<s3-table :loading="loading" :data="data" :thead="thead" :oprations="oprations" :checkbox="checkbox" @checkRow="checkRow"></s3-table>
    <s3-page :total="total" @page-change="currentChange"></s3-page>
	</div>
</template>

<script>
import s3Search from '@/components/s3-search'
import s3Table from '@/components/s3-table'
import s3Page from '@/components/s3-page'

export default {
   data(){
    return {
       data: [],
       thead:config.modules.myorder.list,
       oprations:[{
        name:'删除',
        fun:function(index,row){console.log(index)
          console.log(row)}
       }],
       checkbox:true,
       loading:true,
       total:10
     }
   },
   computed:{
     appid () {
       return this.$store.state.appid
     }
   },
   methods:{
    checkRow (selection) {
      console.log(selection) 
    },
    currentChange (val) {
      console.log(val)
    }
   },
   created(){
    s3.ajax('/order/orderList',{},this.appid)
    .then(res => {
      if(res.status==="000"){
        this.data=res.orderList;
        this.thead[0].fixed = true
        this.total=res.total;
        this.loading = true;
      }
    })
   },
  components:{
      s3Search,
      s3Table,
      s3Page
    } 
}
</script>

<style scoped>
	.page{margin-top:30px;float:right;}
</style>
