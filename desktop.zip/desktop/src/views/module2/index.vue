<template>
	<div>
		<el-container>
			<el-aside v-if="navList.length>0">
				<s3-leftMenu :navList="navList"></s3-leftMenu>
			</el-aside>
			<el-main>
				<router-view class="view"></router-view>
			</el-main>
		</el-container>
	</div>
</template>
</template>

<script>

export default{
	data () {
		return {
			navList:[]
		}
	},
  computed:{
    appid () {
      return this.$store.state.appid
    }
  },
	created(){
      s3.ajax('/config/leftNav',{},this.appid)
        .then(res => {
          this.navList = res.menuList;
      })
    },
    components:{

	}
}


</script>

<style scoped>
</style>
