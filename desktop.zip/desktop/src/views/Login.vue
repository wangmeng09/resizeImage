<template>
  <div class="main">
    <p class="loginTitle">
      <span>{{basic.companyName}}供应链服务平台</span>
    </p>
    <img class="loginPic" :src="basic.loginPic" >
    <s3-login v-show="!isLoggedIn"
      :logo="basic.logo"
      :success="success"
      :company="basic.companyName">
    </s3-login>
    <s3-firstlogin :success="success" v-show="isLoggedIn && firstLogin"></s3-firstlogin>
    <s3-footer :company="basic.companyName" :logo="basic.logo" class="footer"></s3-footer>
  </div>
</template>

<script>

export default {
  data () {
    return {
      basic: config.basic,
      success: '/'
    }
  },
  computed: {
    firstLogin: {
      get: function(){
        return this.$store.state.USER_FIRST_LOGIN
      },
      set: function(){
        this.$store.commit('USER_FIRST_LOGIN',this.firstLogin)
      }
    },
    isLoggedIn () {
      return this.$store.state.USER_LOG_IN
    }
  },
  mounted () {
    this.$store.commit('USER_LOG_OUT')
  }
}
</script>
<style scoped>
  .loginTitle{position: absolute;top:10px;left:100px;font-size: 12px;color:#fff;}
  .loginPic{width:100%;height:843px;margin-bottom:-5px;}
</style>
