<template>
	<div class="page">
		<el-container>
			<el-aside v-if="navList.length>0">
				<s3-leftMenu :navList="navList"></s3-leftMenu>
			</el-aside>
			<el-main>
				<router-view class="view"></router-view>
			</el-main>
		</el-container>
	</div>
</template>

<script>
import s3LeftMenu from '@/components/s3-leftMenu'
import s3Breadcrumb from '@/components/s3-breadcrumb'

export default{
	data () {
		return {
			navList:[]
		}
	},
  computed:{
    appid () {
      return this.$store.state.appid
    }
  },
	created(){
    console.log(this.appid)
      //获取导航数据
      s3.ajax('/config/leftNav',{},this.appid)
        .then(res => {
          this.navList = res.menuList;
      })
    },
    components:{
		s3LeftMenu,
		s3Breadcrumb
	}
}


</script>

<style scoped>
	
</style>
