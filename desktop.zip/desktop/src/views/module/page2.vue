<template>
  <div>
    <s3-search></s3-search>
    <s3-table :tableData="tableData" :tableTitle="tableTitle"></s3-table>
  </div>
	</el-main>
</template>
<script>
import s3Search from '@/components/s3-search'
import s3Table from '@/components/s3-table'
export default {
  components:{
    s3Table,
    s3Search
  },
  data(){
    return {
       tableData: [],
       tableTitle:config.modules.myorder.list
     }
   },
   computed:{
     appid () {
       return this.$store.state.appid
     }
   },
   created(){
     s3.ajax('/order/orderBean.getOrderInfoList',{},this.appid)
       .then(res => {
       console.log(res)
     if(res.status==="000"){
       this.tableData=res.orderList;
       this.total=res.total;
     }
   })
   }
}
</script>
