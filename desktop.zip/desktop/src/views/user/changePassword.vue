<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>修改密码</span>
    </div>
    <div class="text item infoMain">
      <s3changPass ></s3changPass>
    </div>

    <div class="tip">
      <p>温馨提示：</p>
      <p>请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。</p>
      <p>为了保护您账号的安全,请不要将密码设置为其他网站(如:其它游戏、邮箱、聊天工具等)相同的密码。</p>
      <p>建议您每隔一段时间修改您的密码，以防密码泄漏。</p>
    </div>

  </el-card>
</template>
<script>
  import s3changPass from '@/components/s3-changePassword'
	export default {
		components:{s3changPass},
    data(){
      return{

      }
    }
	}
</script>
<style scoped>
  .infoMain{width:500px;margin:0 auto;}
  .tip{width:600px;margin:50px auto;font-size:12px;line-height: 30px;position: relative;left: 50px;}
</style>
