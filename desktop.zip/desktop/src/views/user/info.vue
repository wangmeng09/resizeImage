<template>
	<el-card class="box-card">
		<div slot="header" class="clearfix">
			<span>用户信息</span>
		</div>
		<div class="text item infoMain">
			
			<el-form label-position="left" :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-form-item label="客户编号">
		        <el-input :disabled="true" readonly="true" placeholder="请输入客户编号" v-model="user.UserEntitycustomId"></el-input>
		    </el-form-item>

		    <el-form-item label="登录名">
		        <el-input :disabled="true" readonly="true" placeholder="请输入登录名" v-model="user.UserEntityloginName"></el-input>
		    </el-form-item>

		    <el-form-item label="客户名称">
		        <el-input :disabled="true" readonly="true" placeholder="请输入客户名称" v-model="user.UserEntityuserName"></el-input>
		    </el-form-item>

				<el-form-item label="联系手机">
		        <el-input style="width:315px;margin-right:10px;" readonly="true" placeholder="请输入联系手机" v-model="user.UserEntitymobilephone"></el-input>
		        <el-button v-if="showEdit" class="btn" type="primary" @click="edit">修改</el-button>
			    	<el-button v-if="showquit" class="btn" type="danger" icon="el-icon-close" @click="quit"></el-button>
		    </el-form-item>
				
				<transition name="slide">
					<div class="phone" v-show="show">
					  <el-form-item label="手机号" prop="phone">
				      <el-input placeholder="请输入手机号" v-model.number="ruleForm.phone"></el-input>
				    </el-form-item>
						
						<el-form-item label="验证码" prop="validatecode">
			        <el-input style="width:279px;margin-right: 10px;" placeholder="请输入验证码" v-model.number="ruleForm.validatecode"></el-input>
			        <el-button :disabled="!isPhoneValid" style="padding: 12px 10px;" type="primary" @click="getValidateCode(ruleForm.phone,user.UserEntityloginName)">{{getCodeText}}</el-button>
			    	</el-form-item>

			    	<el-form-item>
					    <el-button class="btn" type="primary" @click="savePhone('ruleForm')">提交</el-button>
					  </el-form-item>

					</div>
				</transition>
			</el-form>

		</div>
	</el-card>
</template>
<script>
	import {Message} from 'element-ui';

	export default {
		data(){

			//验证手机号
      var phone = (rule, value, callback) => {
      	var val = value+"";
        if (!value) {
          return callback(new Error('手机号不能为空'));
        }
        if (!Number.isInteger(value)) {
          return callback(new Error('请输入数字值'));
        }  
        if (val.length !==11){
        	return callback(new Error('手机号位数不正确'));
        }
        else {
          callback();
        }
      };

			return {
				showEdit:true,
				showquit:false,
				show:false,
				getCodeText: '获取验证码',
        count: 60, //倒计时
				ruleForm: {
					phone:'',
					validatecode:''
        },
        rules: {
        	phone: [
        	 	{ required: true, validator: phone, trigger: 'blur' }
          ],
          validatecode: [
        	 	{ required: true, message: '请输入验证码', trigger: 'blur' },
        	 	{ type: 'number', message: '验证码必须为数字值'}
          ]
        }
			}
		},
		methods:{
			edit(){
				this.showEdit = false;
				this.showquit = true;
				this.show = true;
			},

			quit(){
				this.showEdit = true;
				this.showquit = false;
				this.show = false;
			},

     	getValidateCode:function (phone,loginName) {
        //ajax请求
        var param = {
          mobile:phone,
          appid:this.appid
        }
        if(loginName)
          param.loginName = loginName;

        //显示提示信息
        s3.ajax('/validateCode',param,'usermanage')
        .then( result => {
          if(result.retCode == "200")
            Message('短信验证码以向您的手机发送，请在输入框内填入您收到的验证码！');
          else
            Message(result.retMsg||"您的账号暂不能使用忘记密码功能，请联系企业咨询!");
        })

        //点击之后 倒计时
        const f =  () => {
          this.count--;
          this.getCodeText = `请等待 ${this.count} s`;
          if (this.count == 1) {
            this.getCodeText = "获取验证码";
          }
        }
        s3.timer.interval(f,0,1000,60000);
      },

      savePhone(formName) {
      	this.$refs[formName].validate((valid) => {
       		if (valid) {
						this.showEdit = true;
						this.showSave = false;
         		console.log("ok");
        	} else {
	          console.log('error submit!!');
	          return false;
	        }
      	});
     	},
		},
		computed:{
			user () {
				console.log(this.$store.state.currentUser);
				return this.$store.state.currentUser
			},
			appid () {
        return this.$store.state.appid
      },
      //手机号验证
      isPhoneValid() {
        return /^1[3|5|7|8][0-9]\d{8}$/.test(this.ruleForm.phone);
      }
		}
	}
</script>

<style scoped>
	.infoMain{width:500px;margin:0 auto;}

	.slide-enter-active,.slide-leave-active{
		transition: all .3s;
	}
	.slide-enter,.slide-leave-to{
		transform:translateY(100%);
		opacity:0;
	}
</style>