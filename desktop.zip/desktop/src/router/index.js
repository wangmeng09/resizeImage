import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store'
import Main from '@/views/main'
import Login from '@/views/Login'
Vue.use(VueRouter)


let loginRoutes = []
try {
  let loginConfig = config.basic.login
  loginRoutes = [
    {
      path: '/login',
      name: '',
      meta: {
        allowBack:false
      },
      component: Login
    }
  ]
}catch(e){

}

let routes = [
  {
    path: '/',
    redirect: '/main/home'
  },
  {
    path: '/main',
    component: Main,
    children:[
      {
        path: '/',
        component: resolve => {require(['@/views/index/index'], resolve)}
      },
      {
        path: 'home',
        name:'首页',
        component: resolve => {require(['@/views/index/index'], resolve)}
      },
      {
        path: '/user/info',
        component: resolve => {require(['@/views/user/info'], resolve)}
      },
      {
        path: '/user/changePwd',
        component: resolve => {require(['@/views/user/changePassword'], resolve)}
      },
      {
        path: 'module1',
        component: function (resolve){require(['@/views/module/index'], resolve)},
        children:[
          {
            path: 'page1',
            name:'',
            component: resolve => {require(['@/views/module/page1'], resolve)}
          },
          {
            path: 'page2',
            name:'demo页1',
            component: resolve => {require(['@/views/module/page2'], resolve)}
          },
          {
            path: 'page3',
            name:'demo页1',
            component: resolve => {require(['@/views/module/page3'], resolve)}
          },
          {
            path: 'page4',
            name:'demo页1',
            component: resolve => {require(['@/views/module/page4'], resolve)}
          }
        ]
      },
      {
        path: 'module2',
        component:  resolve => {require(['@/views/module2/index'], resolve)},
        children:[
          {
            path: 'page1',
            name:'',
            component: resolve => {require(['@/views/module2/page1'], resolve)}
          }
        ]
      }
    ]
  },
  {
    path:'/main/module2/page2',
    component: resolve => {
      require(['@/views/module2/page1'], resolve)
    }
  }
]

routes = loginRoutes.concat(routes)

var router = new VueRouter({
  routes
})


var routerList = []
/**
 * 导航守卫
 * to: Route: 即将要进入的目标 路由对象
 * from: Route: 当前导航正要离开的路由
 * next: Function: 一定要调用该方法来 resolve 这个钩子。执行效果依赖 next 方法的调用参数。
 *
*/
router.beforeEach((to, from, next) => {


  var index = routerList.indexOf(to.name);

  if(index !== -1){
    routerList.splice(index+1,routerList.length-index-1)
  } else {
    routerList.push(to.name)
  }
  to.meta.routerList = routerList

  
  let backState = ''
  if(to.meta.backState){
    backState = to.meta.backState
  }else if(to.path !== '/login' && to.path !== '/home' && to.path !== '/'){
    backState = from.path
  }

  let page = {
    title: to.name,
    backState: backState,
    goHome: to.meta.goHome || false
  }
  store.commit('pageinfo', page)
  // 进登录页面直接进，不用判登录
  if(config.basic.login == false || to.path == '/login'){
    next()
  }else if(!store.getters.isLogedIn ||　store.state.isFirstLogedIn) {
    next({
      path: '/login'
    })
  }else{
    next()
  }
})

router.afterEach((to, from) => {
  // 进入路由后
})

export default router
