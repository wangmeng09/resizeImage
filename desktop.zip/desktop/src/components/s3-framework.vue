<template>
	<el-container>
		<el-header class="head">
	      <div class="head_main">
	        <div class="head_main_logo">
	          <img :src="logo" alt="">
	          <span>{{company}}</span>
	        </div>
	        <div class="head_main_info">
	          当前角色
        <el-select style="width:100px;margin-right:10px;" size="mini" v-model="value" placeholder="请选择">
	            <el-option v-for="item in roles" :key="item.value" :label="item.label" :value="item.value"></el-option>
	          </el-select>
	          <s3-userinfo></s3-userinfo>
	        </div>
	      </div>
	    </el-header>
	    <el-main>
	    	<s3-nav :nav="nav"></s3-nav>
    		<router-view class="view"></router-view>
	    </el-main>
	    <el-footer>
	     {{company}}copyright@{{fullyear}}
	    <img class="logo" :src="logo" alt="" width="80" height="30">
    </el-footer>
	</el-container>
</template>
<script>

export default {
	import s3userinfo from '@/components/s3-userinfo'

	data () {
	    return {
	      nav:[]
	  }
	},
	props:{
	    roles: {
	      type: Array,
	      required: true
	    },
	    company: {
	      type: String,
	      default:'核心企业电子供应链平台'
	    },
	    logo:{
	      type: String,
	      default:'http://file.gongyinju.com/group1/M00/00/5B/bQYdm1mH6MCARxkxAABfhUPd7bM324.jpg'
	    }
	},
	created(){
	    //获取导航数据
	    s3.ajax('/nav',{},'config')
	      .then(res =>{
	        this.nav = res.roleList;
	    })
	  }
	components:{
		s3userinfo
	}
}
</script>