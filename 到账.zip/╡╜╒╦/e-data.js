var dom1 = document.getElementById("container1");
var myChart1 = echarts.init(dom1);
var app1 = {};
option1 = null;
app1.title = '坐标轴刻度与标签对齐';

option1 = {
    color: ['#3398DB'],
    tooltip : {
        trigger: 'axis',
        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis : [
        {
            type : 'category',
            data : ['2017-1', '2', '3', '4', '5', '6', '7'],
            axisTick: {
                alignWithLabel: true,
                show:false,//隐藏刻度线
            },
            axisLabel:{
                color:"#000"//刻度文字颜色
            }
        }
    ],
    yAxis : [
        {
            show : false
        }
    ],
    series : [
        {
            name:'直接访问',
            type:'bar',
            barWidth: '6%',
            data:[10, 52, 200, 334, 390, 330, 220],
            itemStyle:{
                normal:{
                    color:'#45c3f5'//柱子颜色
                }
            },
            barWidth:20,//柱型宽度
            label:{//文字标注
                normal:{
                    show:true,
                    position:'top',
                    textStyle: {
                        color: '#45c3f5'
                    }
                }
            }
        }
    ]
};

if (option1 && typeof option1 === "object") {
    myChart1.setOption(option1, true);
}



var dom = document.getElementById("container");
var myChart = echarts.init(dom);
var app = {};
option = null;
option = {
    series : [
        {
            name: '访问来源',
            type: 'pie',
            radius: ['25%', '60%'],//大小
            avoidLabelOverlap: false,
            center: ['50%', '50%'],//位置
            data:[
                {value:335, name:'易付'},
                // {value:310, name:'往来户'},
                {value:234, name:'管家卡'}
            ],
            // label:{
            //     normal{

            //     }
            // },
            labelLine:{
                normal:{
                    length:10//靠近圆引导线长度
                }
            },
            itemStyle: {
                normal:{
                    label:{
                        show:true,
                        position:'outer',
                        formatter:'{b}\n{d}%',
                    }
                },
                emphasis: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                },
            }
        }
    ],
    color:['#ea5e45','#35a0f0']
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}


